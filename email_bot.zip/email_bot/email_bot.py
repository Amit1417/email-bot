import smtplib
import ssl
import csv
import time
import logging
from email.message import EmailMessage
from pathlib import Path
import os

# ---------------- CONFIG ----------------

SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587

SENDER_EMAIL = "profesortoky0578@gmail.com"
APP_PASSWORD = os.getenv("EMAIL_APP_PASSWORD")

CSV_FILE = "recipients.csv"
ATTACHMENT_PATH = "resume.pdf"

MAX_RETRIES = 3
RETRY_DELAY = 5

# ---------------- LOGGING ----------------

logging.basicConfig(
    filename="email_log.txt",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

# ---------------- EMAIL BUILDER ----------------

def create_email(to_email, name, company):

    msg = EmailMessage()
    msg["From"] = SENDER_EMAIL
    msg["To"] = to_email
    msg["Subject"] = f"Internship offer letter {name}"

    body = f"""


Dear {name},

We are pleased to inform you that you have been selected for the position of Internship Role with {company}

Congratulations! Based on your profile and interview, we are happy to offer you this internship opportunity with our team. Please find your internship offer letter attached with this email containing details about your role, duration, stipend (if applicable), and terms.

Kindly review the document carefully and confirm your acceptance by replying to this email with a signed copy of the offer letter on or before [last date].

If you have any questions or need clarification regarding any terms, feel free to contact us.

We look forward to having you join our team.

Best regards,
[Amit]
HR Department

.

Regards,
Karan
"""

    msg.set_content(body)

    file_path = Path(ATTACHMENT_PATH)

    if file_path.exists():
        with open(file_path, "rb") as f:
            msg.add_attachment(
                f.read(),
                maintype="application",
                subtype="octet-stream",
                filename=file_path.name
            )

    return msg

# ---------------- SEND WITH RETRY ----------------

def send_with_retry(server, msg, to_email):

    for attempt in range(1, MAX_RETRIES + 1):

        try:
            server.send_message(msg)
            print("Sent:", to_email)
            logging.info("SUCCESS → " + to_email)
            return True

        except Exception as e:
            print("Retry failed:", to_email)
            logging.error(f"Attempt {attempt} → {to_email} → {e}")
            time.sleep(RETRY_DELAY)

    return False

# ---------------- MAIN ----------------

def send_bulk_emails():

    context = ssl.create_default_context()

    with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
        server.starttls(context=context)
        server.login(SENDER_EMAIL, APP_PASSWORD)

        with open(CSV_FILE, newline="") as file:
            reader = csv.DictReader(file)

            for row in reader:
                msg = create_email(
                    row["email"],
                    row["name"],
                    row["company"]
                )

                send_with_retry(server, msg, row["email"])

# ---------------- RUN ----------------

if __name__ == "__main__":
    send_bulk_emails()
